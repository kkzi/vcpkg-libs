/* file      : odb/mysql/details/config-vc.h
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#ifndef ODB_MYSQL_DETAILS_CONFIG_VC_H
#define ODB_MYSQL_DETAILS_CONFIG_VC_H

#if !defined(LIBODB_MYSQL_INCLUDE_SHORT) && !defined (LIBODB_MYSQL_INCLUDE_LONG)
#  define LIBODB_MYSQL_INCLUDE_SHORT 1
#endif

#endif /* ODB_MYSQL_DETAILS_CONFIG_VC_H */
