// file      : odb/details/lock.cxx
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/details/lock.hxx>

namespace odb
{
  namespace details
  {
    // This otherwise unnecessary file is here to allow instantiation
    // of inline functions for exporting.
  }
}
