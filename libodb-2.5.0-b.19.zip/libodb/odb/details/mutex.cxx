// file      : odb/details/mutex.cxx
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/details/mutex.hxx>

namespace odb
{
  namespace details
  {
    // This otherwise unnecessary file is here to allow instantiation
    // of inline functions for exporting.
  }
}
